import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.lang.*;

final public class Calculator {
    //process the question utility question
    private  Calculator(){}
    //change magic number
    public static final int NUMBER_OF_FOUR = 12 ;
    //set default parameter
    static private double leftOperand = NUMBER_OF_FOUR;
    static private double rightOperand = 2;
    static private double result = 0;
    //set text for displaying result
    static class OperatorListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String op = ((JButton)e.getSource()).getText();
            resultLabel.setText("");
            operatorLabel.setText(op);
        }
    }
    //write listener function
    static class EqualListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            leftOperand = Double.parseDouble(leftLabel.getText());
            rightOperand= Double.parseDouble(rightLabel.getText());
            String op = operatorLabel.getText();
            //use equals instead of "=="
            if (op.equals("+")) {
                result = leftOperand + (rightOperand);
            } else if (op.equals("-")) {
                result = leftOperand - (rightOperand);
            } else if (op.equals("*")) {
                result = leftOperand * (rightOperand);
            } else if (op.equals("/")) {
                result = leftOperand / (rightOperand);
            } 
            //convert number to  text
            resultLabel.setText(Double.toString(result));
        }
    }
    //change magic number
    public static final int NUMBER_OF_ONE = 5 ;
    public static final int NUMBER_OF_TWO = 400 ;
    public static final int NUMBER_OF_THREE = 200 ; 
    //set the  first line swing
    static private JTextField leftLabel = new JTextField(Double.toString(leftOperand));
    static private JLabel operatorLabel = new JLabel("");
    static private JTextField rightLabel = new JTextField(Double.toString(rightOperand));
    static private JLabel equalLabel = new JLabel("=");
    static private JLabel resultLabel = new JLabel("");

    static public void main(String[] args) {
        String[] ops = {"+", "-", "*", "/"};
        JFrame frame = new JFrame("Calculator");
        frame.setVisible(true);
        frame.setSize(NUMBER_OF_TWO, NUMBER_OF_THREE);
        frame.setLayout(new GridLayout(0, NUMBER_OF_ONE));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //add swing
        frame.add(leftLabel);
        frame.add(operatorLabel);
        frame.add(rightLabel);
        frame.add(equalLabel);
        frame.add(resultLabel);
        //complete layout
        leftLabel.setHorizontalAlignment(SwingConstants.CENTER);
        rightLabel.setHorizontalAlignment(SwingConstants.CENTER);
        operatorLabel.setHorizontalAlignment(SwingConstants.CENTER);
        equalLabel.setHorizontalAlignment(SwingConstants.CENTER);
        resultLabel.setHorizontalAlignment(SwingConstants.CENTER);
        leftLabel.setBorder(BorderFactory.createLineBorder(Color.gray));
        rightLabel.setBorder(BorderFactory.createLineBorder(Color.gray));
        operatorLabel.setBorder(BorderFactory.createLineBorder(Color.gray));
        equalLabel.setBorder(BorderFactory.createLineBorder(Color.gray));
        resultLabel.setBorder(BorderFactory.createLineBorder(Color.gray));
        //add listener
        for (String str: ops) {
            JButton btn = new JButton(str);
            btn.addActionListener(new OperatorListener());
            frame.add(btn);
        }
        //print result
        JButton eq = new JButton("OK");
        eq.addActionListener(new EqualListener());
        frame.add(eq);
    }
}
