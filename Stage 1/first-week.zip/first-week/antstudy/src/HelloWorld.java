public class HelloWorld {
	private String string_out  ;
	public void hello()
	{
		string_out = "Hello World!";
	}
	public String hello()
	{
		return string_out ;
	}
}